<?php

include_once '../vendor/autoload.php';

use App\Yt\controller\PlaylistController;

$ctrl = new PlaylistController();


header('Content-Type:application/json');
echo json_encode($ctrl->getPlaylist());
/*
echo '<pre>';
var_dump($ctrl->getPlaylist());
echo '</pre>';*/