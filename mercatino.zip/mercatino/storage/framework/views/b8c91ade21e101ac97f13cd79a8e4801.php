

<?php $__env->startSection('content'); ?>
    <main class="container my-4">
        <div class="card">
            <div class="card-body">
                <h1 class="card-title"><?php echo e($product->name); ?></h1>
                <p class="card-text"><strong>Category:</strong> <?php echo e($product->category->name); ?></p>
                <p class="card-text"><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                <p class="card-text"><?php echo e($product->description); ?></p>

                <?php if($product->image): ?>
                    <div class="text-center my-3">
                        <img 
                            src="<?php echo e(asset($product->image)); ?>" 
                            alt="<?php echo e($product->name); ?>" 
                            class="img-fluid"
                        >
                    </div>
                <?php endif; ?>

                <p class="card-text">
                    <strong>Created by:</strong> 
                    <a href="<?php echo e(route('user.products', $product->user->id)); ?>">
                        <?php echo e($product->user->name); ?>

                    </a>
                </p>
            </div>
        </div>

        <?php if(auth()->guard()->check()): ?>
            <?php if($product->user_id === auth()->id()): ?>
                <!-- Edit and Delete Options -->
                <div class="mt-4 d-flex gap-2">
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning">Edit Product</a>

                    <form 
                        action="<?php echo e(route('products.destroy', $product->id)); ?>" 
                        method="POST" 
                        onsubmit="return confirm('Are you sure you want to delete this product?');" 
                        style="display: inline;"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete Product</button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CorsoPHP\mercatino\resources\views/products/show.blade.php ENDPATH**/ ?>