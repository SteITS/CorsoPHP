

<?php $__env->startSection('content'); ?>
    <main class="container my-4">
        <h1 class="mb-4">Marketplace Products</h1>

        <!-- Filter Form -->
        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="mb-4">
            <div class="mb-3">
            <label for="search">Search by Title</label>
            <input type="text" name="search" id="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Search for a product...">
                <label for="category" class="form-label">Filter by Category:</label>
                <select name="category" id="category" class="form-select" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>

        <!-- Product List -->
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100">
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text"><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                        </div>
                        <div class="card-footer text-center">
                            <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary">Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($products->links('pagination::bootstrap-5')); ?>

        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CorsoPHP\mercatino\resources\views/products/index.blade.php ENDPATH**/ ?>