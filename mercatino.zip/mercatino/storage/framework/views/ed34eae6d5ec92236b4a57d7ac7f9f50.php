
<link 
  rel="stylesheet" 
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" 
  integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLR+1QmJLkhIl5Y53QqMEgKX1pFklzDe1H7V76fI1S" 
  crossorigin="anonymous"
/>
<?php $__env->startSection('content'); ?>
    <main class="container my-4">
        <h1 class="mb-4">Add a New Product</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="name" class="form-label">Product Name:</label>
                <input 
                    type="text" 
                    name="name" 
                    id="name" 
                    class="form-control" 
                    value="<?php echo e(old('name')); ?>" 
                    required
                >
                <div class="invalid-feedback">
                    Please enter a product name.
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <textarea 
                    name="description" 
                    id="description" 
                    rows="5" 
                    class="form-control"
                ><?php echo e(old('description')); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Price:</label>
                <input 
                    type="number" 
                    name="price" 
                    id="price" 
                    step="0.01" 
                    class="form-control" 
                    value="<?php echo e(old('price')); ?>" 
                    required
                >
                <div class="invalid-feedback">
                    Please enter a valid price.
                </div>
            </div>

            <div class="mb-3">
                <label for="category" class="form-label">Category:</label>
                <select 
                    name="category_id" 
                    id="category" 
                    class="form-select" 
                    required
                >
                    <option value="">Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="invalid-feedback">
                    Please select a category.
                </div>
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Product Image:</label>
                <input 
                    type="file" 
                    name="image" 
                    id="image" 
                    class="form-control"
                >
            </div>

            <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CorsoPHP\mercatino\resources\views/products/create.blade.php ENDPATH**/ ?>