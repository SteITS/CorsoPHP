

<?php $__env->startSection('content'); ?>
    <main class="container my-4">
        <h1 class="mb-4">Products by <?php echo e($user->name); ?></h1>

        <?php if($products->isEmpty()): ?>
            <p class="text-muted">No products found for this user.</p>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <div class="card h-100">
                            <?php if($product->image): ?>
                                <img 
                                    src="<?php echo e(asset($product->image)); ?>" 
                                    class="card-img-top" 
                                    alt="<?php echo e($product->name); ?>" 
                                    style="width:100%; height:auto;"
                                >
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                <p class="card-text"><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                                <p class="card-text"><?php echo e($product->description); ?></p>
                            </div>
                            <div class="card-footer text-center">
                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary">Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CorsoPHP\mercatino\resources\views/products/user_products.blade.php ENDPATH**/ ?>