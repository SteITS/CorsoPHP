

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercatino del Rumeno</title>
    <link 
        rel="stylesheet" 
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" 
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLR+1QmJLkhIl5Y53QqMEgKX1pFklzDe1H7V76fI1S" 
        crossorigin="anonymous"
    >
</head>
<body>
<style>
  img {
    max-width: 100%;
    height: auto;
  }
</style>

<?php $__env->startSection('content'); ?>
    <main class="container my-4">
        <?php if(auth()->guard()->check()): ?>
            <div class="mb-4">
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Create New Insertion</a>
            </div>
        <?php endif; ?>

        <!-- Product List -->
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="card h-100">
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text"><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                        </div>
                        <div class="card-footer">
                            <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-outline-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p class="text-center">You have not created any insertion yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CorsoPHP\mercatino\resources\views/products/personal.blade.php ENDPATH**/ ?>