<form action="" method="post" enctype="multipart/form-data">

    <label for="user_id">user_id:</label>
    <input type="text" name="user_id" id="user_id">

    <label for="category_id">category_id:</label>
    <input type="text" name="category_id" id="category_id">

    <label for="name">name:</label>
    <input type="text" name="name" id="name">

    <label for="description">description:</label>
    <input type="text" name="description" id="description">

    <label for="price">price:</label>
    <input type="text" name="price" id="price">

    <label for="image">image:</label>
    <input type="file" name="image" id="image">
    
    <button>Add</button>
</form>