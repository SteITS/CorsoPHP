<nav>
    <a class="btn btn-primary" href="?page=home">Home</a>
    <a class="btn btn-primary" href="?page=galleria">Galleria</a>
    <a class="btn btn-primary" href="?page=contatti">Contatti</a>
</nav>