<?php

//commento single-line
include "header.php"; //file intestazioni comuni

include "content.php";

include "footer.php";












?>