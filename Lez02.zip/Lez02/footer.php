
<!-- Chiusura del div container -->
</div>
<!-- Footer -->
<script src="js/script.js"></script>
<!-- Chiusura di pagina -->
</body>
</html>