<?php echo __FILE__;  ?>
<br>
<?php echo __DIR__;  ?>
<br>
<?php echo __LINE__;  ?>