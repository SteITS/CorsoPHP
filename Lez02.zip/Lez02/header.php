<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="./css/style.css">
    </head>
    <body>

    <div class="container-fluid">
        <?php include "menu.php"; ?>
    </div>

    <!-- Apro il container che chiuderò nel footer -->
    <div class="container">

        

