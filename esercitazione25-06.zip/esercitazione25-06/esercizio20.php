<?php
function massimo($ar){
    return max($ar);
}

$ar= [10,30,23,12,101,65,33,95];
$n=Max($ar);
echo("Il numero max è: ".$n);
?>