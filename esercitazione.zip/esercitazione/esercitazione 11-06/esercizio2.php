<?php
$n1 =5;
$n2 = 15;

echo("Somma: ".$n1+$n2."<br>"."Differenza: ".$n1-$n2."<br>"."Prodotto: ".$n1*$n2."<br>"."Quoziente: ".$n1/$n2);
echo("<br>");

?>