<?php
$pers = array("Mario"=>"22","Luca"=>"19","Brabus"=>"45");
foreach ($pers as $key => $value) {
    echo"". $key ." ". $value ."//";
}
?>