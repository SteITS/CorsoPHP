<?php
$i=1;
while($i< 11){
    echo $i." ";
    $i++;
}
?>