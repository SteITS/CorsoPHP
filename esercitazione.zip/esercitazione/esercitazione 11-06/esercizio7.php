<?php
$num = array("Cane","Gatto","Piccione","Serpente","Lombrico");
foreach($num as $key) {
    echo ($key." ");
}
?>