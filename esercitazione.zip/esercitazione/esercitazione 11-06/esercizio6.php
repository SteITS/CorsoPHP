<?php
function prodotto($n1,$n2){
    return $n1 * $n2;
}

echo(prodotto(rand(-100,100),rand(-100,100)))
?>