<?php
$stringa="Viata mea, e si buna si rea";
echo(strlen($stringa));  
?>