<?php

namespace model;
class prodotto {

    public function __construct(
        public string $nome,

        public float $prezzo
    ){}

}

?>